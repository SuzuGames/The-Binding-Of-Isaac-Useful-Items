package net.suzu.thebindingofisaac.procedures;

import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;

public class BasementProcedure {
	public static void execute(double x, double y, double z) {
		double xOff = 0;
		double yOff = 0;
		double zOff = 0;
		double Rand = 0;
		xOff = x + 5;
		yOff = y;
		zOff = z + 8;
		for (int index0 = 0; index0 < Mth.nextInt(RandomSource.create(), 5, 15); index0++) {
			Rand = Mth.nextInt(RandomSource.create(), 1, 100);
			if (Rand < 25) {
				xOff = xOff + 11;
			}
		}
	}
}
