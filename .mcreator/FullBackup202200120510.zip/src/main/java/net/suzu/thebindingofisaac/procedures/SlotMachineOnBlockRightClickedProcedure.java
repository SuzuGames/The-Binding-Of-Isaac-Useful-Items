package net.suzu.thebindingofisaac.procedures;

import net.suzu.thebindingofisaac.item.PennyItem;
import net.suzu.thebindingofisaac.item.NickelItem;
import net.suzu.thebindingofisaac.item.DimeItem;
import net.suzu.thebindingofisaac.TboiSuzuMod;

import net.minecraftforge.registries.ForgeRegistries;

import net.minecraft.world.World;
import net.minecraft.world.IWorld;
import net.minecraft.world.GameType;
import net.minecraft.world.Explosion;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.ResourceLocation;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tags.ItemTags;
import net.minecraft.tags.ITag;
import net.minecraft.item.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Item;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.item.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.Entity;
import net.minecraft.client.network.play.NetworkPlayerInfo;
import net.minecraft.client.entity.player.AbstractClientPlayerEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.block.BlockState;

import java.util.Random;
import java.util.Map;

public class SlotMachineOnBlockRightClickedProcedure {

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("world") == null) {
			if (!dependencies.containsKey("world"))
				TboiSuzuMod.LOGGER.warn("Failed to load dependency world for procedure SlotMachineOnBlockRightClicked!");
			return;
		}
		if (dependencies.get("x") == null) {
			if (!dependencies.containsKey("x"))
				TboiSuzuMod.LOGGER.warn("Failed to load dependency x for procedure SlotMachineOnBlockRightClicked!");
			return;
		}
		if (dependencies.get("y") == null) {
			if (!dependencies.containsKey("y"))
				TboiSuzuMod.LOGGER.warn("Failed to load dependency y for procedure SlotMachineOnBlockRightClicked!");
			return;
		}
		if (dependencies.get("z") == null) {
			if (!dependencies.containsKey("z"))
				TboiSuzuMod.LOGGER.warn("Failed to load dependency z for procedure SlotMachineOnBlockRightClicked!");
			return;
		}
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				TboiSuzuMod.LOGGER.warn("Failed to load dependency entity for procedure SlotMachineOnBlockRightClicked!");
			return;
		}
		IWorld world = (IWorld) dependencies.get("world");
		double x = dependencies.get("x") instanceof Integer ? (int) dependencies.get("x") : (double) dependencies.get("x");
		double y = dependencies.get("y") instanceof Integer ? (int) dependencies.get("y") : (double) dependencies.get("y");
		double z = dependencies.get("z") instanceof Integer ? (int) dependencies.get("z") : (double) dependencies.get("z");
		Entity entity = (Entity) dependencies.get("entity");
		double repeatTimes = 0;
		double randomItem = 0;
		if (!world.isRemote()) {
			if (ItemTags.getCollection().getTagByID(new ResourceLocation("tboi_suzu:coin"))
					.contains(((entity instanceof LivingEntity) ? ((LivingEntity) entity).getHeldItemMainhand() : ItemStack.EMPTY).getItem())) {
				if (((entity instanceof LivingEntity) ? ((LivingEntity) entity).getHeldItemMainhand() : ItemStack.EMPTY)
						.getItem() == PennyItem.block) {
					if (!(new Object() {
						public boolean checkGamemode(Entity _ent) {
							if (_ent instanceof ServerPlayerEntity) {
								return ((ServerPlayerEntity) _ent).interactionManager.getGameType() == GameType.CREATIVE;
							} else if (_ent instanceof PlayerEntity && _ent.world.isRemote()) {
								NetworkPlayerInfo _npi = Minecraft.getInstance().getConnection()
										.getPlayerInfo(((AbstractClientPlayerEntity) _ent).getGameProfile().getId());
								return _npi != null && _npi.getGameType() == GameType.CREATIVE;
							}
							return false;
						}
					}.checkGamemode(entity))) {
						if (entity instanceof PlayerEntity) {
							ItemStack _stktoremove = new ItemStack(PennyItem.block);
							((PlayerEntity) entity).inventory.func_234564_a_(p -> _stktoremove.getItem() == p.getItem(), (int) 1,
									((PlayerEntity) entity).container.func_234641_j_());
						}
					}
					repeatTimes = 1;
				} else if (((entity instanceof LivingEntity) ? ((LivingEntity) entity).getHeldItemMainhand() : ItemStack.EMPTY)
						.getItem() == NickelItem.block) {
					if (!(new Object() {
						public boolean checkGamemode(Entity _ent) {
							if (_ent instanceof ServerPlayerEntity) {
								return ((ServerPlayerEntity) _ent).interactionManager.getGameType() == GameType.CREATIVE;
							} else if (_ent instanceof PlayerEntity && _ent.world.isRemote()) {
								NetworkPlayerInfo _npi = Minecraft.getInstance().getConnection()
										.getPlayerInfo(((AbstractClientPlayerEntity) _ent).getGameProfile().getId());
								return _npi != null && _npi.getGameType() == GameType.CREATIVE;
							}
							return false;
						}
					}.checkGamemode(entity))) {
						if (entity instanceof PlayerEntity) {
							ItemStack _stktoremove = new ItemStack(NickelItem.block);
							((PlayerEntity) entity).inventory.func_234564_a_(p -> _stktoremove.getItem() == p.getItem(), (int) 1,
									((PlayerEntity) entity).container.func_234641_j_());
						}
					}
					repeatTimes = 5;
				} else if (((entity instanceof LivingEntity) ? ((LivingEntity) entity).getHeldItemMainhand() : ItemStack.EMPTY)
						.getItem() == DimeItem.block) {
					if (!(new Object() {
						public boolean checkGamemode(Entity _ent) {
							if (_ent instanceof ServerPlayerEntity) {
								return ((ServerPlayerEntity) _ent).interactionManager.getGameType() == GameType.CREATIVE;
							} else if (_ent instanceof PlayerEntity && _ent.world.isRemote()) {
								NetworkPlayerInfo _npi = Minecraft.getInstance().getConnection()
										.getPlayerInfo(((AbstractClientPlayerEntity) _ent).getGameProfile().getId());
								return _npi != null && _npi.getGameType() == GameType.CREATIVE;
							}
							return false;
						}
					}.checkGamemode(entity))) {
						if (entity instanceof PlayerEntity) {
							ItemStack _stktoremove = new ItemStack(DimeItem.block);
							((PlayerEntity) entity).inventory.func_234564_a_(p -> _stktoremove.getItem() == p.getItem(), (int) 1,
									((PlayerEntity) entity).container.func_234641_j_());
						}
					}
					repeatTimes = 10;
				}
				for (int index0 = 0; index0 < (int) (repeatTimes); index0++) {
					if (!world.isRemote()) {
						BlockPos _bp = new BlockPos(x, y, z);
						TileEntity _tileEntity = world.getTileEntity(_bp);
						BlockState _bs = world.getBlockState(_bp);
						if (_tileEntity != null)
							_tileEntity.getTileData().putDouble("boom", (MathHelper.nextInt(new Random(), 1, 15)));
						if (world instanceof World)
							((World) world).notifyBlockUpdate(_bp, _bs, _bs, 3);
					}
					if (MathHelper.nextInt(new Random(), 1, 10) <= 4) {
						randomItem = (MathHelper.nextInt(new Random(), 1, 6));
						if (randomItem == 1) {
							for (int index1 = 0; index1 < (int) (MathHelper.nextInt(new Random(), 1, 5)); index1++) {
								if (world instanceof World && !world.isRemote()) {
									ItemEntity entityToSpawn = new ItemEntity((World) world, x, y, z, new ItemStack((new Object() {
										public Item getRandomItem(ResourceLocation name) {
											ITag<Item> _tag = ItemTags.getCollection().getTagByID(name);
											return _tag.getAllElements().isEmpty() ? Items.AIR : _tag.getRandomElement(new Random());
										}
									}.getRandomItem(new ResourceLocation("tboi_suzu:coin")))));
									entityToSpawn.setPickupDelay((int) 10);
									world.addEntity(entityToSpawn);
								}
							}
						}
						if (randomItem == 2) {
							for (int index2 = 0; index2 < (int) (MathHelper.nextInt(new Random(), 1, 4)); index2++) {
								if (world instanceof World && !world.isRemote()) {
									ItemEntity entityToSpawn = new ItemEntity((World) world, x, y, z, new ItemStack((new Object() {
										public Item getRandomItem(ResourceLocation name) {
											ITag<Item> _tag = ItemTags.getCollection().getTagByID(name);
											return _tag.getAllElements().isEmpty() ? Items.AIR : _tag.getRandomElement(new Random());
										}
									}.getRandomItem(new ResourceLocation("tboi_suzu:heart")))));
									entityToSpawn.setPickupDelay((int) 10);
									world.addEntity(entityToSpawn);
								}
							}
						}
						if (randomItem == 3) {
							for (int index3 = 0; index3 < (int) (MathHelper.nextInt(new Random(), 1, 2)); index3++) {
								if (world instanceof World && !world.isRemote()) {
									ItemEntity entityToSpawn = new ItemEntity((World) world, x, y, z, new ItemStack((new Object() {
										public Item getRandomItem(ResourceLocation name) {
											ITag<Item> _tag = ItemTags.getCollection().getTagByID(name);
											return _tag.getAllElements().isEmpty() ? Items.AIR : _tag.getRandomElement(new Random());
										}
									}.getRandomItem(new ResourceLocation("tboi_suzu:pill")))));
									entityToSpawn.setPickupDelay((int) 10);
									world.addEntity(entityToSpawn);
								}
							}
						}
						if (randomItem == 4) {
							for (int index4 = 0; index4 < (int) (MathHelper.nextInt(new Random(), 1, 3)); index4++) {
								if (world instanceof World && !world.isRemote()) {
									ItemEntity entityToSpawn = new ItemEntity((World) world, x, y, z, new ItemStack((new Object() {
										public Item getRandomItem(ResourceLocation name) {
											ITag<Item> _tag = ItemTags.getCollection().getTagByID(name);
											return _tag.getAllElements().isEmpty() ? Items.AIR : _tag.getRandomElement(new Random());
										}
									}.getRandomItem(new ResourceLocation("tboi_suzu:bomb")))));
									entityToSpawn.setPickupDelay((int) 10);
									world.addEntity(entityToSpawn);
								}
							}
						}
						if (randomItem == 5) {
							for (int index5 = 0; index5 < (int) (MathHelper.nextInt(new Random(), 1, 3)); index5++) {
								if (world instanceof World && !world.isRemote()) {
									ItemEntity entityToSpawn = new ItemEntity((World) world, x, y, z, new ItemStack((new Object() {
										public Item getRandomItem(ResourceLocation name) {
											ITag<Item> _tag = ItemTags.getCollection().getTagByID(name);
											return _tag.getAllElements().isEmpty() ? Items.AIR : _tag.getRandomElement(new Random());
										}
									}.getRandomItem(new ResourceLocation("tboi_suzu:key")))));
									entityToSpawn.setPickupDelay((int) 10);
									world.addEntity(entityToSpawn);
								}
							}
						}
						if (randomItem == 6) {
							if (MathHelper.nextInt(new Random(), 1, 10) <= 2) {
								for (int index6 = 0; index6 < (int) (MathHelper.nextInt(new Random(), 1, 2)); index6++) {
									if (world instanceof World && !world.isRemote()) {
										ItemEntity entityToSpawn = new ItemEntity((World) world, x, y, z, new ItemStack((new Object() {
											public Item getRandomItem(ResourceLocation name) {
												ITag<Item> _tag = ItemTags.getCollection().getTagByID(name);
												return _tag.getAllElements().isEmpty() ? Items.AIR : _tag.getRandomElement(new Random());
											}
										}.getRandomItem(new ResourceLocation("tboi_suzu:e_card")))));
										entityToSpawn.setPickupDelay((int) 10);
										world.addEntity(entityToSpawn);
									}
								}
							} else {
								for (int index7 = 0; index7 < (int) (MathHelper.nextInt(new Random(), 1, 2)); index7++) {
									if (world instanceof World && !world.isRemote()) {
										ItemEntity entityToSpawn = new ItemEntity((World) world, x, y, z, new ItemStack((new Object() {
											public Item getRandomItem(ResourceLocation name) {
												ITag<Item> _tag = ItemTags.getCollection().getTagByID(name);
												return _tag.getAllElements().isEmpty() ? Items.AIR : _tag.getRandomElement(new Random());
											}
										}.getRandomItem(new ResourceLocation("tboi_suzu:card")))));
										entityToSpawn.setPickupDelay((int) 10);
										world.addEntity(entityToSpawn);
									}
								}
							}
						}
					}
					if (new Object() {
						public double getValue(IWorld world, BlockPos pos, String tag) {
							TileEntity tileEntity = world.getTileEntity(pos);
							if (tileEntity != null)
								return tileEntity.getTileData().getDouble(tag);
							return -1;
						}
					}.getValue(world, new BlockPos(x, y, z), "boom") == 1) {
						if (world instanceof World && !((World) world).isRemote) {
							((World) world).createExplosion(null, (int) x, (int) y, (int) z, (float) 0.5, Explosion.Mode.NONE);
						}
						world.destroyBlock(new BlockPos(x, y, z), false);
					}
				}
				if (world instanceof World && !world.isRemote()) {
					((World) world).playSound(null, new BlockPos(x, y, z),
							(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("tboi_suzu:coin_slot")),
							SoundCategory.BLOCKS, (float) 1, (float) 1);
				} else {
					((World) world).playSound(x, y, z,
							(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("tboi_suzu:coin_slot")),
							SoundCategory.BLOCKS, (float) 1, (float) 1, false);
				}
			} else {
				if (entity instanceof PlayerEntity && !entity.world.isRemote()) {
					((PlayerEntity) entity).sendStatusMessage(new StringTextComponent("You need a coin"), (true));
				}
			}
		}
	}
}
