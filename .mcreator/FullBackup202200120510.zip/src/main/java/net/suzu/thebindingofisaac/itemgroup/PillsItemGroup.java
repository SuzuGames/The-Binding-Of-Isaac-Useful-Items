
package net.suzu.thebindingofisaac.itemgroup;

import net.suzu.thebindingofisaac.item.Pill1Item;
import net.suzu.thebindingofisaac.TboiSuzuModElements;

import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemGroup;

@TboiSuzuModElements.ModElement.Tag
public class PillsItemGroup extends TboiSuzuModElements.ModElement {
	public PillsItemGroup(TboiSuzuModElements instance) {
		super(instance, 112);
	}

	@Override
	public void initElements() {
		tab = new ItemGroup("tabpills") {
			@OnlyIn(Dist.CLIENT)
			@Override
			public ItemStack createIcon() {
				return new ItemStack(Pill1Item.block);
			}

			@OnlyIn(Dist.CLIENT)
			public boolean hasSearchBar() {
				return false;
			}
		};
	}

	public static ItemGroup tab;
}
