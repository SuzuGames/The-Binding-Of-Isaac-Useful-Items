package net.suzu.thebindingofisaac.procedures;

import net.suzu.thebindingofisaac.item.SoulHeartItem;
import net.suzu.thebindingofisaac.item.RedHeartItem;
import net.suzu.thebindingofisaac.TboiSuzuModVariables;
import net.suzu.thebindingofisaac.TboiSuzuMod;

import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.items.ItemHandlerHelper;
import net.minecraftforge.items.CapabilityItemHandler;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.common.MinecraftForge;

import net.minecraft.world.server.ServerWorld;
import net.minecraft.world.World;
import net.minecraft.world.IWorld;
import net.minecraft.world.GameType;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.util.math.vector.Vector2f;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.Hand;
import net.minecraft.util.DamageSource;
import net.minecraft.potion.Effects;
import net.minecraft.potion.EffectInstance;
import net.minecraft.item.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.item.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.Entity;
import net.minecraft.command.ICommandSource;
import net.minecraft.command.CommandSource;
import net.minecraft.client.network.play.NetworkPlayerInfo;
import net.minecraft.client.entity.player.AbstractClientPlayerEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.block.Blocks;

import java.util.stream.Stream;
import java.util.concurrent.atomic.AtomicReference;
import java.util.Random;
import java.util.Map;
import java.util.HashMap;
import java.util.Collections;
import java.util.AbstractMap;

public class PillRightclickedProcedure {

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("world") == null) {
			if (!dependencies.containsKey("world"))
				TboiSuzuMod.LOGGER.warn("Failed to load dependency world for procedure PillRightclicked!");
			return;
		}
		if (dependencies.get("x") == null) {
			if (!dependencies.containsKey("x"))
				TboiSuzuMod.LOGGER.warn("Failed to load dependency x for procedure PillRightclicked!");
			return;
		}
		if (dependencies.get("y") == null) {
			if (!dependencies.containsKey("y"))
				TboiSuzuMod.LOGGER.warn("Failed to load dependency y for procedure PillRightclicked!");
			return;
		}
		if (dependencies.get("z") == null) {
			if (!dependencies.containsKey("z"))
				TboiSuzuMod.LOGGER.warn("Failed to load dependency z for procedure PillRightclicked!");
			return;
		}
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				TboiSuzuMod.LOGGER.warn("Failed to load dependency entity for procedure PillRightclicked!");
			return;
		}
		IWorld world = (IWorld) dependencies.get("world");
		double x = dependencies.get("x") instanceof Integer ? (int) dependencies.get("x") : (double) dependencies.get("x");
		double y = dependencies.get("y") instanceof Integer ? (int) dependencies.get("y") : (double) dependencies.get("y");
		double z = dependencies.get("z") instanceof Integer ? (int) dependencies.get("z") : (double) dependencies.get("z");
		Entity entity = (Entity) dependencies.get("entity");
		double loopNum = 0;
		double itemNum = 0;
		double itemNum2 = 0;
		double C_x = 0;
		double C_y = 0;
		double C_z = 0;
		if (!world.isRemote()) {
			if (!(new Object() {
				public boolean checkGamemode(Entity _ent) {
					if (_ent instanceof ServerPlayerEntity) {
						return ((ServerPlayerEntity) _ent).interactionManager.getGameType() == GameType.CREATIVE;
					} else if (_ent instanceof PlayerEntity && _ent.world.isRemote()) {
						NetworkPlayerInfo _npi = Minecraft.getInstance().getConnection()
								.getPlayerInfo(((AbstractClientPlayerEntity) _ent).getGameProfile().getId());
						return _npi != null && _npi.getGameType() == GameType.CREATIVE;
					}
					return false;
				}
			}.checkGamemode(entity))) {
				if (entity instanceof LivingEntity) {
					ItemStack _setstack = new ItemStack(Blocks.AIR);
					_setstack.setCount((int) 1);
					((LivingEntity) entity).setHeldItem(Hand.MAIN_HAND, _setstack);
					if (entity instanceof ServerPlayerEntity)
						((ServerPlayerEntity) entity).inventory.markDirty();
				}
			}
			if ((entity.getCapability(TboiSuzuModVariables.PLAYER_VARIABLES_CAPABILITY, null)
					.orElse(new TboiSuzuModVariables.PlayerVariables())).pill == 0) {
				{
					double _setval = (MathHelper.nextInt(new Random(), 1, 16));
					entity.getCapability(TboiSuzuModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.pill = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
			} else {
				if ((entity.getCapability(TboiSuzuModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new TboiSuzuModVariables.PlayerVariables())).pill == 1) {
					if (world instanceof ServerWorld) {
						((World) world).getServer().getCommandManager().handleCommand(
								new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO, (ServerWorld) world, 4, "",
										new StringTextComponent(""), ((World) world).getServer(), null).withFeedbackDisabled(),
								"/summon area_effect_cloud ~ ~.50 ~ {Particle:\"snowflake 0 50 0 1\",Radius:8f,Duration:20,Effects:[{Id:19b,Amplifier:0b,Duration:100}]}");
					}
					if (entity instanceof LivingEntity)
						((LivingEntity) entity).addPotionEffect(new EffectInstance(Effects.RESISTANCE, (int) 30, (int) 200, (false), (false)));
					new Object() {
						private int ticks = 0;
						private float waitTicks;
						private IWorld world;

						public void start(IWorld world, int waitTicks) {
							this.waitTicks = waitTicks;
							MinecraftForge.EVENT_BUS.register(this);
							this.world = world;
						}

						@SubscribeEvent
						public void tick(TickEvent.ServerTickEvent event) {
							if (event.phase == TickEvent.Phase.END) {
								this.ticks += 1;
								if (this.ticks >= this.waitTicks)
									run();
							}
						}

						private void run() {
							if (entity instanceof LivingEntity) {
								((LivingEntity) entity).removePotionEffect(Effects.POISON);
							}
							MinecraftForge.EVENT_BUS.unregister(this);
						}
					}.start(world, (int) 20);
					if (world instanceof World && !world.isRemote()) {
						((World) world).playSound(null, new BlockPos(x, y, z),
								(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("tboi_suzu:bad_gas")),
								SoundCategory.VOICE, (float) 1, (float) 1);
					} else {
						((World) world).playSound(x, y, z,
								(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("tboi_suzu:bad_gas")),
								SoundCategory.VOICE, (float) 1, (float) 1, false);
					}
				}
				if ((entity.getCapability(TboiSuzuModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new TboiSuzuModVariables.PlayerVariables())).pill == 2) {
					if (((entity instanceof LivingEntity) ? ((LivingEntity) entity).getHealth() : -1) <= 6) {
						if (entity instanceof LivingEntity)
							((LivingEntity) entity)
									.setHealth((float) ((entity instanceof LivingEntity) ? ((LivingEntity) entity).getMaxHealth() : -1));
					} else {
						entity.attackEntityFrom(DamageSource.GENERIC, (float) 6);
						if (world instanceof World && !world.isRemote()) {
							((World) world).playSound(null, new BlockPos(x, y, z),
									(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("tboi_suzu:bad_trip")),
									SoundCategory.VOICE, (float) 1, (float) 1);
						} else {
							((World) world).playSound(x, y, z,
									(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("tboi_suzu:bad_trip")),
									SoundCategory.VOICE, (float) 1, (float) 1, false);
						}
					}
				}
				if ((entity.getCapability(TboiSuzuModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new TboiSuzuModVariables.PlayerVariables())).pill == 3) {
					for (int index0 = 0; index0 < (int) (2); index0++) {
						if (world instanceof World && !world.isRemote()) {
							ItemEntity entityToSpawn = new ItemEntity((World) world, (x + MathHelper.nextInt(new Random(), -4, 4)), (y + 1),
									(z + MathHelper.nextInt(new Random(), -4, 4)), new ItemStack(SoulHeartItem.block));
							entityToSpawn.setPickupDelay((int) 10);
							world.addEntity(entityToSpawn);
						}
					}
					if (world instanceof World && !world.isRemote()) {
						((World) world)
								.playSound(null, new BlockPos(x, y, z),
										(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS
												.getValue(new ResourceLocation("tboi_suzu:balls_of_steel")),
										SoundCategory.VOICE, (float) 1, (float) 1);
					} else {
						((World) world).playSound(x, y, z,
								(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS
										.getValue(new ResourceLocation("tboi_suzu:balls_of_steel")),
								SoundCategory.VOICE, (float) 1, (float) 1, false);
					}
				}
				if ((entity.getCapability(TboiSuzuModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new TboiSuzuModVariables.PlayerVariables())).pill == 4) {
					loopNum = 0;
					itemNum = 0;
					for (int index1 = 0; index1 < (int) (36); index1++) {
						if (Items.IRON_INGOT == (new Object() {
							public ItemStack getItemStack(int sltid, Entity entity) {
								AtomicReference<ItemStack> _retval = new AtomicReference<>(ItemStack.EMPTY);
								entity.getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY, null).ifPresent(capability -> {
									_retval.set(capability.getStackInSlot(sltid).copy());
								});
								return _retval.get();
							}
						}.getItemStack((int) (loopNum), entity)).getItem()) {
							itemNum = (itemNum + ((new Object() {
								public ItemStack getItemStack(int sltid, Entity entity) {
									AtomicReference<ItemStack> _retval = new AtomicReference<>(ItemStack.EMPTY);
									entity.getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY, null).ifPresent(capability -> {
										_retval.set(capability.getStackInSlot(sltid).copy());
									});
									return _retval.get();
								}
							}.getItemStack((int) (loopNum), entity))).getCount());
						}
						loopNum = (loopNum + 1);
					}
					loopNum = 0;
					itemNum2 = 0;
					for (int index2 = 0; index2 < (int) (36); index2++) {
						if (Items.GOLD_INGOT == (new Object() {
							public ItemStack getItemStack(int sltid, Entity entity) {
								AtomicReference<ItemStack> _retval = new AtomicReference<>(ItemStack.EMPTY);
								entity.getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY, null).ifPresent(capability -> {
									_retval.set(capability.getStackInSlot(sltid).copy());
								});
								return _retval.get();
							}
						}.getItemStack((int) (loopNum), entity)).getItem()) {
							itemNum2 = (itemNum2 + ((new Object() {
								public ItemStack getItemStack(int sltid, Entity entity) {
									AtomicReference<ItemStack> _retval = new AtomicReference<>(ItemStack.EMPTY);
									entity.getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY, null).ifPresent(capability -> {
										_retval.set(capability.getStackInSlot(sltid).copy());
									});
									return _retval.get();
								}
							}.getItemStack((int) (loopNum), entity))).getCount());
						}
						loopNum = (loopNum + 1);
					}
					if (entity instanceof PlayerEntity && !entity.world.isRemote()) {
						((PlayerEntity) entity).sendStatusMessage(new StringTextComponent((itemNum + ", " + itemNum2)), (true));
					}
					if (entity instanceof PlayerEntity) {
						ItemStack _stktoremove = new ItemStack(Items.GOLD_INGOT);
						((PlayerEntity) entity).inventory.func_234564_a_(p -> _stktoremove.getItem() == p.getItem(), (int) itemNum2,
								((PlayerEntity) entity).container.func_234641_j_());
					}
					if (entity instanceof PlayerEntity) {
						ItemStack _stktoremove = new ItemStack(Items.IRON_INGOT);
						((PlayerEntity) entity).inventory.func_234564_a_(p -> _stktoremove.getItem() == p.getItem(), (int) itemNum,
								((PlayerEntity) entity).container.func_234641_j_());
					}
					if (entity instanceof PlayerEntity) {
						ItemStack _setstack = new ItemStack(Items.IRON_INGOT);
						_setstack.setCount((int) itemNum2);
						ItemHandlerHelper.giveItemToPlayer(((PlayerEntity) entity), _setstack);
					}
					if (entity instanceof PlayerEntity) {
						ItemStack _setstack = new ItemStack(Items.GOLD_INGOT);
						_setstack.setCount((int) itemNum);
						ItemHandlerHelper.giveItemToPlayer(((PlayerEntity) entity), _setstack);
					}
					if (world instanceof World && !world.isRemote()) {
						((World) world)
								.playSound(null, new BlockPos(x, y, z),
										(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS
												.getValue(new ResourceLocation("tboi_suzu:bombs_are_key")),
										SoundCategory.VOICE, (float) 1, (float) 1);
					} else {
						((World) world)
								.playSound(x, y, z,
										(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS
												.getValue(new ResourceLocation("tboi_suzu:bombs_are_key")),
										SoundCategory.VOICE, (float) 1, (float) 1, false);
					}
				}
				if ((entity.getCapability(TboiSuzuModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new TboiSuzuModVariables.PlayerVariables())).pill == 5) {
					ExplosiveDiahrreaProcedure.executeProcedure(Stream
							.of(new AbstractMap.SimpleEntry<>("world", world), new AbstractMap.SimpleEntry<>("entity", entity),
									new AbstractMap.SimpleEntry<>("x", x), new AbstractMap.SimpleEntry<>("y", y),
									new AbstractMap.SimpleEntry<>("z", z))
							.collect(HashMap::new, (_m, _e) -> _m.put(_e.getKey(), _e.getValue()), Map::putAll));
					if (world instanceof World && !world.isRemote()) {
						((World) world)
								.playSound(null, new BlockPos(x, y, z),
										(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS
												.getValue(new ResourceLocation("tboi_suzu:explosive_diarrhea")),
										SoundCategory.VOICE, (float) 1, (float) 1);
					} else {
						((World) world).playSound(x, y, z,
								(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS
										.getValue(new ResourceLocation("tboi_suzu:explosive_diarrhea")),
								SoundCategory.VOICE, (float) 1, (float) 1, false);
					}
				}
				if ((entity.getCapability(TboiSuzuModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new TboiSuzuModVariables.PlayerVariables())).pill == 6) {
					if (entity instanceof LivingEntity)
						((LivingEntity) entity).setHealth((float) ((entity instanceof LivingEntity) ? ((LivingEntity) entity).getMaxHealth() : -1));
					if (world instanceof World && !world.isRemote()) {
						((World) world).playSound(null, new BlockPos(x, y, z),
								(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("tboi_suzu:full_health")),
								SoundCategory.VOICE, (float) 1, (float) 1);
					} else {
						((World) world).playSound(x, y, z,
								(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("tboi_suzu:full_health")),
								SoundCategory.VOICE, (float) 1, (float) 1, false);
					}
				}
				if ((entity.getCapability(TboiSuzuModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new TboiSuzuModVariables.PlayerVariables())).pill == 7) {
					if (world instanceof ServerWorld) {
						((World) world).getServer().getCommandManager().handleCommand(
								new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO, (ServerWorld) world, 4, "",
										new StringTextComponent(""), ((World) world).getServer(), null).withFeedbackDisabled(),
								("attribute @p generic.max_health base set placeholder".replace("placeholder",
										"" + (((entity instanceof LivingEntity) ? ((LivingEntity) entity).getMaxHealth() : -1) - 2))));
					}
					if (world instanceof World && !world.isRemote()) {
						((World) world).playSound(null, new BlockPos(x, y, z),
								(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("tboi_suzu:health_down")),
								SoundCategory.NEUTRAL, (float) 1, (float) 1);
					} else {
						((World) world).playSound(x, y, z,
								(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("tboi_suzu:health_down")),
								SoundCategory.NEUTRAL, (float) 1, (float) 1, false);
					}
				}
				if ((entity.getCapability(TboiSuzuModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new TboiSuzuModVariables.PlayerVariables())).pill == 8) {
					if (world instanceof ServerWorld) {
						((World) world).getServer().getCommandManager().handleCommand(
								new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO, (ServerWorld) world, 4, "",
										new StringTextComponent(""), ((World) world).getServer(), null).withFeedbackDisabled(),
								("attribute @p generic.max_health base set placeholder".replace("placeholder",
										"" + (((entity instanceof LivingEntity) ? ((LivingEntity) entity).getMaxHealth() : -1) + 2))));
					}
					if (world instanceof World && !world.isRemote()) {
						((World) world).playSound(null, new BlockPos(x, y, z),
								(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("tboi_suzu:health_up")),
								SoundCategory.VOICE, (float) 1, (float) 1);
					} else {
						((World) world).playSound(x, y, z,
								(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("tboi_suzu:health_up")),
								SoundCategory.VOICE, (float) 1, (float) 1, false);
					}
				}
				if ((entity.getCapability(TboiSuzuModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new TboiSuzuModVariables.PlayerVariables())).pill == 9) {
					if (entity instanceof LivingEntity)
						((LivingEntity) entity).addPotionEffect(new EffectInstance(Effects.NAUSEA, (int) 200, (int) 1, (false), (false)));
					if (world instanceof World && !world.isRemote()) {
						((World) world)
								.playSound(null, new BlockPos(x, y, z),
										(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS
												.getValue(new ResourceLocation("tboi_suzu:i_found_pills")),
										SoundCategory.VOICE, (float) 1, (float) 1);
					} else {
						((World) world)
								.playSound(x, y, z,
										(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS
												.getValue(new ResourceLocation("tboi_suzu:i_found_pills")),
										SoundCategory.VOICE, (float) 1, (float) 1, false);
					}
				}
				if ((entity.getCapability(TboiSuzuModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new TboiSuzuModVariables.PlayerVariables())).pill == 10) {
					entity.getPersistentData().putDouble("puberty", (entity.getPersistentData().getDouble("puberty") + 1));
					if (entity.getPersistentData().getDouble("puberty") == 3) {
						if (world instanceof ServerWorld) {
							((World) world).getServer().getCommandManager().handleCommand(
									new CommandSource(ICommandSource.DUMMY, new Vector3d(x, y, z), Vector2f.ZERO, (ServerWorld) world, 4, "",
											new StringTextComponent(""), ((World) world).getServer(), null).withFeedbackDisabled(),
									("attribute @p generic.max_health base set placeholder".replace("placeholder",
											"" + (((entity instanceof LivingEntity) ? ((LivingEntity) entity).getMaxHealth() : -1) + 2))));
						}
					}
					if (world instanceof World && !world.isRemote()) {
						((World) world).playSound(null, new BlockPos(x, y, z),
								(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("tboi_suzu:puberty")),
								SoundCategory.VOICE, (float) 1, (float) 1);
					} else {
						((World) world).playSound(x, y, z,
								(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("tboi_suzu:puberty")),
								SoundCategory.VOICE, (float) 1, (float) 1, false);
					}
				}
				if ((entity.getCapability(TboiSuzuModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new TboiSuzuModVariables.PlayerVariables())).pill == 11) {
					if (world instanceof World && !world.isRemote()) {
						ItemEntity entityToSpawn = new ItemEntity((World) world, (MathHelper.nextInt(new Random(), -4, 4) + x), (1 + y),
								(MathHelper.nextInt(new Random(), -4, 4) + z), new ItemStack(Items.LEATHER_HELMET));
						entityToSpawn.setPickupDelay((int) 10);
						world.addEntity(entityToSpawn);
					}
					if (world instanceof World && !world.isRemote()) {
						ItemEntity entityToSpawn = new ItemEntity((World) world, (MathHelper.nextInt(new Random(), -4, 4) + x), (1 + y),
								(MathHelper.nextInt(new Random(), -4, 4) + z), new ItemStack(Items.LEATHER_CHESTPLATE));
						entityToSpawn.setPickupDelay((int) 10);
						world.addEntity(entityToSpawn);
					}
					if (world instanceof World && !world.isRemote()) {
						ItemEntity entityToSpawn = new ItemEntity((World) world, (MathHelper.nextInt(new Random(), -4, 4) + x), (1 + y),
								(MathHelper.nextInt(new Random(), -4, 4) + z), new ItemStack(Items.LEATHER_LEGGINGS));
						entityToSpawn.setPickupDelay((int) 10);
						world.addEntity(entityToSpawn);
					}
					if (world instanceof World && !world.isRemote()) {
						ItemEntity entityToSpawn = new ItemEntity((World) world, (MathHelper.nextInt(new Random(), -4, 4) + x), (1 + y),
								(MathHelper.nextInt(new Random(), -4, 4) + z), new ItemStack(Items.LEATHER_BOOTS));
						entityToSpawn.setPickupDelay((int) 10);
						world.addEntity(entityToSpawn);
					}
					if (world instanceof World && !world.isRemote()) {
						((World) world).playSound(null, new BlockPos(x, y, z),
								(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("tboi_suzu:pretty_fly")),
								SoundCategory.VOICE, (float) 1, (float) 1);
					} else {
						((World) world).playSound(x, y, z,
								(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("tboi_suzu:pretty_fly")),
								SoundCategory.VOICE, (float) 1, (float) 1, false);
					}
				}
				if ((entity.getCapability(TboiSuzuModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new TboiSuzuModVariables.PlayerVariables())).pill == 12) {
					if (world instanceof World && !world.isRemote()) {
						((World) world).playSound(null, new BlockPos(x, y, z),
								(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("tboi_suzu:telepills")),
								SoundCategory.VOICE, (float) 1, (float) 1);
					} else {
						((World) world).playSound(x, y, z,
								(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("tboi_suzu:telepills")),
								SoundCategory.VOICE, (float) 1, (float) 1, false);
					}
					new Object() {
						private int ticks = 0;
						private float waitTicks;
						private IWorld world;

						public void start(IWorld world, int waitTicks) {
							this.waitTicks = waitTicks;
							MinecraftForge.EVENT_BUS.register(this);
							this.world = world;
						}

						@SubscribeEvent
						public void tick(TickEvent.ServerTickEvent event) {
							if (event.phase == TickEvent.Phase.END) {
								this.ticks += 1;
								if (this.ticks >= this.waitTicks)
									run();
							}
						}

						private void run() {
							System.out.println("sound");
							MinecraftForge.EVENT_BUS.unregister(this);
						}
					}.start(world, (int) 20);
					C_x = (MathHelper.nextInt(new Random(), -1000, 1000));
					C_y = (MathHelper.nextInt(new Random(), 100, 64));
					C_z = (MathHelper.nextInt(new Random(), -1000, 1000));
					while (!world.canBlockSeeSky(new BlockPos(x, y, z))) {
						C_x = (MathHelper.nextInt(new Random(), -1000, 1000));
						C_y = (MathHelper.nextInt(new Random(), 100, 64));
						C_z = (MathHelper.nextInt(new Random(), -1000, 1000));
					}
					{
						Entity _ent = entity;
						_ent.setPositionAndUpdate(C_x, C_y, C_z);
						if (_ent instanceof ServerPlayerEntity) {
							((ServerPlayerEntity) _ent).connection.setPlayerLocation(C_x, C_y, C_z, _ent.rotationYaw, _ent.rotationPitch,
									Collections.emptySet());
						}
					}
					if (world instanceof World && !world.isRemote()) {
						((World) world).playSound(null, new BlockPos(C_x, C_y, C_y),
								(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("tboi_suzu:telepills")),
								SoundCategory.VOICE, (float) 1, (float) 1);
					} else {
						((World) world).playSound(C_x, C_y, C_y,
								(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("tboi_suzu:telepills")),
								SoundCategory.VOICE, (float) 1, (float) 1, false);
					}
				}
				if ((entity.getCapability(TboiSuzuModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new TboiSuzuModVariables.PlayerVariables())).pill == 13) {
					for (int index4 = 0; index4 < (int) (24); index4++) {
						if (world instanceof World && !world.isRemote()) {
							ItemEntity entityToSpawn = new ItemEntity((World) world, (MathHelper.nextInt(new Random(), -4, 4) + x), (1 + y),
									(MathHelper.nextInt(new Random(), -4, 4) + z), new ItemStack(Items.APPLE));
							entityToSpawn.setPickupDelay((int) 10);
							world.addEntity(entityToSpawn);
						}
					}
					if (world instanceof World && !world.isRemote()) {
						((World) world).playSound(null, new BlockPos(x, y, z),
								(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("tboi_suzu:energy48")),
								SoundCategory.VOICE, (float) 1, (float) 1);
					} else {
						((World) world).playSound(x, y, z,
								(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("tboi_suzu:energy48")),
								SoundCategory.VOICE, (float) 1, (float) 1, false);
					}
				}
				if ((entity.getCapability(TboiSuzuModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new TboiSuzuModVariables.PlayerVariables())).pill == 14) {
					if (entity instanceof LivingEntity)
						((LivingEntity) entity).setHealth((float) 2);
					for (int index5 = 0; index5 < (int) (MathHelper.nextInt(new Random(), 1, 7)); index5++) {
						if (world instanceof World && !world.isRemote()) {
							ItemEntity entityToSpawn = new ItemEntity((World) world, (MathHelper.nextInt(new Random(), -4, 4) + x), (1 + y),
									(MathHelper.nextInt(new Random(), -4, 4) + z), new ItemStack(RedHeartItem.block));
							entityToSpawn.setPickupDelay((int) 10);
							world.addEntity(entityToSpawn);
						}
					}
					if (world instanceof World && !world.isRemote()) {
						((World) world).playSound(null, new BlockPos(x, y, z),
								(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("tboi_suzu:hematemesis")),
								SoundCategory.VOICE, (float) 1, (float) 1);
					} else {
						((World) world).playSound(x, y, z,
								(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("tboi_suzu:hematemesis")),
								SoundCategory.VOICE, (float) 1, (float) 1, false);
					}
				}
				if ((entity.getCapability(TboiSuzuModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new TboiSuzuModVariables.PlayerVariables())).pill == 15) {
					if (entity instanceof LivingEntity)
						((LivingEntity) entity).addPotionEffect(new EffectInstance(Effects.MINING_FATIGUE, (int) 40, (int) 9, (false), (false)));
					if (entity instanceof LivingEntity)
						((LivingEntity) entity).addPotionEffect(new EffectInstance(Effects.SLOWNESS, (int) 40, (int) 9, (false), (false)));
					if (world instanceof World && !world.isRemote()) {
						((World) world).playSound(null, new BlockPos(x, y, z),
								(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("tboi_suzu:paralysis")),
								SoundCategory.VOICE, (float) 1, (float) 1);
					} else {
						((World) world).playSound(x, y, z,
								(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("tboi_suzu:paralysis")),
								SoundCategory.VOICE, (float) 1, (float) 1, false);
					}
				}
				if ((entity.getCapability(TboiSuzuModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new TboiSuzuModVariables.PlayerVariables())).pill == 16) {
					if (entity instanceof LivingEntity)
						((LivingEntity) entity).addPotionEffect(new EffectInstance(Effects.BLINDNESS, (int) 300, (int) 9, (false), (false)));
					if (world instanceof World && !world.isRemote()) {
						((World) world).playSound(null, new BlockPos(x, y, z),
								(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("tboi_suzu:amnesia")),
								SoundCategory.VOICE, (float) 1, (float) 1);
					} else {
						((World) world).playSound(x, y, z,
								(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("tboi_suzu:amnesia")),
								SoundCategory.VOICE, (float) 1, (float) 1, false);
					}
				}
				{
					double _setval = (MathHelper.nextInt(new Random(), 1, 16));
					entity.getCapability(TboiSuzuModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.pill = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
			}
		}
	}
}
