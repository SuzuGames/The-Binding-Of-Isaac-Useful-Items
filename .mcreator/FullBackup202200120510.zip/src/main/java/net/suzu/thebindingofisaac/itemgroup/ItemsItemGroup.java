
package net.suzu.thebindingofisaac.itemgroup;

import net.suzu.thebindingofisaac.item.GuppysPawItem;
import net.suzu.thebindingofisaac.TboiSuzuModElements;

import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemGroup;

@TboiSuzuModElements.ModElement.Tag
public class ItemsItemGroup extends TboiSuzuModElements.ModElement {
	public ItemsItemGroup(TboiSuzuModElements instance) {
		super(instance, 160);
	}

	@Override
	public void initElements() {
		tab = new ItemGroup("tabitems") {
			@OnlyIn(Dist.CLIENT)
			@Override
			public ItemStack createIcon() {
				return new ItemStack(GuppysPawItem.block);
			}

			@OnlyIn(Dist.CLIENT)
			public boolean hasSearchBar() {
				return true;
			}
		}.setBackgroundImageName("item_search.png");
	}

	public static ItemGroup tab;
}
