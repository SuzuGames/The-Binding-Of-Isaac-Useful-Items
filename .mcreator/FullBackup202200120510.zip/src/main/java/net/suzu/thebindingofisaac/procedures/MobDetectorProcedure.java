package net.suzu.thebindingofisaac.procedures;

import net.suzu.thebindingofisaac.TboiSuzuMod;

import net.minecraft.entity.monster.SlimeEntity;
import net.minecraft.entity.monster.MonsterEntity;
import net.minecraft.entity.Entity;

import java.util.Map;

public class MobDetectorProcedure {

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				TboiSuzuMod.LOGGER.warn("Failed to load dependency entity for procedure MobDetector!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		if (entity instanceof MonsterEntity || entity instanceof SlimeEntity) {
			entity.getPersistentData().putBoolean("isMob", (true));
		}
	}
}
