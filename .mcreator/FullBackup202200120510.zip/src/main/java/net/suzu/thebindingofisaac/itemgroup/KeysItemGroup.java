
package net.suzu.thebindingofisaac.itemgroup;

import net.suzu.thebindingofisaac.item.KeyItem;
import net.suzu.thebindingofisaac.TboiSuzuModElements;

import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemGroup;

@TboiSuzuModElements.ModElement.Tag
public class KeysItemGroup extends TboiSuzuModElements.ModElement {
	public KeysItemGroup(TboiSuzuModElements instance) {
		super(instance, 141);
	}

	@Override
	public void initElements() {
		tab = new ItemGroup("tabkeys") {
			@OnlyIn(Dist.CLIENT)
			@Override
			public ItemStack createIcon() {
				return new ItemStack(KeyItem.block);
			}

			@OnlyIn(Dist.CLIENT)
			public boolean hasSearchBar() {
				return false;
			}
		};
	}

	public static ItemGroup tab;
}
