package net.suzu.thebindingofisaac.procedures;

import net.suzu.thebindingofisaac.item.RedHeartItem;
import net.suzu.thebindingofisaac.item.BombItem;
import net.suzu.thebindingofisaac.TboiSuzuMod;

import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.common.MinecraftForge;

import net.minecraft.world.server.ServerWorld;
import net.minecraft.world.World;
import net.minecraft.world.IWorld;
import net.minecraft.world.GameType;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.util.math.vector.Vector2f;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.Hand;
import net.minecraft.item.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.item.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.Entity;
import net.minecraft.command.ICommandSource;
import net.minecraft.command.CommandSource;
import net.minecraft.client.network.play.NetworkPlayerInfo;
import net.minecraft.client.entity.player.AbstractClientPlayerEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.block.Blocks;

import java.util.Random;
import java.util.Map;

public class JusticeRightclickedProcedure {

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("world") == null) {
			if (!dependencies.containsKey("world"))
				TboiSuzuMod.LOGGER.warn("Failed to load dependency world for procedure JusticeRightclicked!");
			return;
		}
		if (dependencies.get("x") == null) {
			if (!dependencies.containsKey("x"))
				TboiSuzuMod.LOGGER.warn("Failed to load dependency x for procedure JusticeRightclicked!");
			return;
		}
		if (dependencies.get("y") == null) {
			if (!dependencies.containsKey("y"))
				TboiSuzuMod.LOGGER.warn("Failed to load dependency y for procedure JusticeRightclicked!");
			return;
		}
		if (dependencies.get("z") == null) {
			if (!dependencies.containsKey("z"))
				TboiSuzuMod.LOGGER.warn("Failed to load dependency z for procedure JusticeRightclicked!");
			return;
		}
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				TboiSuzuMod.LOGGER.warn("Failed to load dependency entity for procedure JusticeRightclicked!");
			return;
		}
		IWorld world = (IWorld) dependencies.get("world");
		double x = dependencies.get("x") instanceof Integer ? (int) dependencies.get("x") : (double) dependencies.get("x");
		double y = dependencies.get("y") instanceof Integer ? (int) dependencies.get("y") : (double) dependencies.get("y");
		double z = dependencies.get("z") instanceof Integer ? (int) dependencies.get("z") : (double) dependencies.get("z");
		Entity entity = (Entity) dependencies.get("entity");
		double random = 0;
		if (!world.isRemote()) {
			if (!(new Object() {
				public boolean checkGamemode(Entity _ent) {
					if (_ent instanceof ServerPlayerEntity) {
						return ((ServerPlayerEntity) _ent).interactionManager.getGameType() == GameType.CREATIVE;
					} else if (_ent instanceof PlayerEntity && _ent.world.isRemote()) {
						NetworkPlayerInfo _npi = Minecraft.getInstance().getConnection()
								.getPlayerInfo(((AbstractClientPlayerEntity) _ent).getGameProfile().getId());
						return _npi != null && _npi.getGameType() == GameType.CREATIVE;
					}
					return false;
				}
			}.checkGamemode(entity))) {
				if (entity instanceof LivingEntity) {
					ItemStack _setstack = new ItemStack(Blocks.AIR);
					_setstack.setCount((int) 1);
					((LivingEntity) entity).setHeldItem(Hand.MAIN_HAND, _setstack);
					if (entity instanceof ServerPlayerEntity)
						((ServerPlayerEntity) entity).inventory.markDirty();
				}
			}
			if (world instanceof World && !world.isRemote()) {
				ItemEntity entityToSpawn = new ItemEntity((World) world, (x + MathHelper.nextInt(new Random(), -4, 4)), (y + 1),
						(z + MathHelper.nextInt(new Random(), -4, 4)), new ItemStack(RedHeartItem.block));
				entityToSpawn.setPickupDelay((int) 10);
				world.addEntity(entityToSpawn);
			}
			random = (MathHelper.nextInt(new Random(), 1, 5));
			if (random == 1) {
				if (world instanceof World && !world.isRemote()) {
					ItemEntity entityToSpawn = new ItemEntity((World) world, (x + MathHelper.nextInt(new Random(), -4, 4)), (y + 1),
							(z + MathHelper.nextInt(new Random(), -4, 4)), new ItemStack(Items.WOODEN_PICKAXE));
					entityToSpawn.setPickupDelay((int) 10);
					world.addEntity(entityToSpawn);
				}
			} else if (random == 2) {
				if (world instanceof World && !world.isRemote()) {
					ItemEntity entityToSpawn = new ItemEntity((World) world, (x + MathHelper.nextInt(new Random(), -4, 4)), (y + 1),
							(z + MathHelper.nextInt(new Random(), -4, 4)), new ItemStack(Items.STONE_PICKAXE));
					entityToSpawn.setPickupDelay((int) 10);
					world.addEntity(entityToSpawn);
				}
			} else if (random == 3) {
				if (world instanceof World && !world.isRemote()) {
					ItemEntity entityToSpawn = new ItemEntity((World) world, (x + MathHelper.nextInt(new Random(), -4, 4)), (y + 1),
							(z + MathHelper.nextInt(new Random(), -4, 4)), new ItemStack(Items.IRON_PICKAXE));
					entityToSpawn.setPickupDelay((int) 10);
					world.addEntity(entityToSpawn);
				}
			} else if (random == 4) {
				if (world instanceof World && !world.isRemote()) {
					ItemEntity entityToSpawn = new ItemEntity((World) world, (x + MathHelper.nextInt(new Random(), -4, 4)), (y + 1),
							(z + MathHelper.nextInt(new Random(), -4, 4)), new ItemStack(Items.GOLDEN_PICKAXE));
					entityToSpawn.setPickupDelay((int) 10);
					world.addEntity(entityToSpawn);
				}
			} else if (random == 5) {
				if (world instanceof World && !world.isRemote()) {
					ItemEntity entityToSpawn = new ItemEntity((World) world, (x + MathHelper.nextInt(new Random(), -4, 4)), (y + 1),
							(z + MathHelper.nextInt(new Random(), -4, 4)), new ItemStack(Items.DIAMOND_PICKAXE));
					entityToSpawn.setPickupDelay((int) 10);
					world.addEntity(entityToSpawn);
				}
			}
			for (int index0 = 0; index0 < (int) (MathHelper.nextInt(new Random(), 1, 5)); index0++) {
				if (MathHelper.nextInt(new Random(), 1, 10) <= 2) {
					if (world instanceof ServerWorld) {
						((World) world).getServer().getCommandManager().handleCommand(
								new CommandSource(ICommandSource.DUMMY,
										new Vector3d((x + MathHelper.nextInt(new Random(), -4, 4)), (y + 7),
												(z + MathHelper.nextInt(new Random(), -4, 4))),
										Vector2f.ZERO, (ServerWorld) world, 4, "", new StringTextComponent(""), ((World) world).getServer(), null)
										.withFeedbackDisabled(),
								"summon minecraft:tnt ~ ~ ~ {Fuse:80}");
					}
				} else {
					if (world instanceof World && !world.isRemote()) {
						ItemEntity entityToSpawn = new ItemEntity((World) world, (x + MathHelper.nextInt(new Random(), -4, 4)), (y + 1),
								(z + MathHelper.nextInt(new Random(), -4, 4)), new ItemStack(BombItem.block));
						entityToSpawn.setPickupDelay((int) 10);
						world.addEntity(entityToSpawn);
					}
				}
			}
			random = (MathHelper.nextInt(new Random(), 1, 8));
			if (random == 1) {
				if (world instanceof World && !world.isRemote()) {
					ItemEntity entityToSpawn = new ItemEntity((World) world, (x + MathHelper.nextInt(new Random(), -4, 4)), (y + 1),
							(z + MathHelper.nextInt(new Random(), -4, 4)), new ItemStack(Items.COAL));
					entityToSpawn.setPickupDelay((int) 10);
					world.addEntity(entityToSpawn);
				}
			} else if (random == 2) {
				if (world instanceof World && !world.isRemote()) {
					ItemEntity entityToSpawn = new ItemEntity((World) world, (x + MathHelper.nextInt(new Random(), -4, 4)), (y + 1),
							(z + MathHelper.nextInt(new Random(), -4, 4)), new ItemStack(Items.IRON_INGOT));
					entityToSpawn.setPickupDelay((int) 10);
					world.addEntity(entityToSpawn);
				}
			} else if (random == 3) {
				if (world instanceof World && !world.isRemote()) {
					ItemEntity entityToSpawn = new ItemEntity((World) world, (x + MathHelper.nextInt(new Random(), -4, 4)), (y + 1),
							(z + MathHelper.nextInt(new Random(), -4, 4)), new ItemStack(Items.LAPIS_LAZULI));
					entityToSpawn.setPickupDelay((int) 10);
					world.addEntity(entityToSpawn);
				}
			} else if (random == 4) {
				if (world instanceof World && !world.isRemote()) {
					ItemEntity entityToSpawn = new ItemEntity((World) world, (x + MathHelper.nextInt(new Random(), -4, 4)), (y + 1),
							(z + MathHelper.nextInt(new Random(), -4, 4)), new ItemStack(Items.GOLD_INGOT));
					entityToSpawn.setPickupDelay((int) 10);
					world.addEntity(entityToSpawn);
				}
			} else if (random == 5) {
				if (world instanceof World && !world.isRemote()) {
					ItemEntity entityToSpawn = new ItemEntity((World) world, (x + MathHelper.nextInt(new Random(), -4, 4)), (y + 1),
							(z + MathHelper.nextInt(new Random(), -4, 4)), new ItemStack(Items.REDSTONE));
					entityToSpawn.setPickupDelay((int) 10);
					world.addEntity(entityToSpawn);
				}
			} else if (random == 6) {
				if (world instanceof World && !world.isRemote()) {
					ItemEntity entityToSpawn = new ItemEntity((World) world, (x + MathHelper.nextInt(new Random(), -4, 4)), (y + 1),
							(z + MathHelper.nextInt(new Random(), -4, 4)), new ItemStack(Items.DIAMOND));
					entityToSpawn.setPickupDelay((int) 10);
					world.addEntity(entityToSpawn);
				}
			} else if (random == 7) {
				if (world instanceof World && !world.isRemote()) {
					ItemEntity entityToSpawn = new ItemEntity((World) world, (x + MathHelper.nextInt(new Random(), -4, 4)), (y + 1),
							(z + MathHelper.nextInt(new Random(), -4, 4)), new ItemStack(Items.EMERALD));
					entityToSpawn.setPickupDelay((int) 10);
					world.addEntity(entityToSpawn);
				}
			} else if (random == 8) {
				if (world instanceof World && !world.isRemote()) {
					ItemEntity entityToSpawn = new ItemEntity((World) world, (x + MathHelper.nextInt(new Random(), -4, 4)), (y + 1),
							(z + MathHelper.nextInt(new Random(), -4, 4)), new ItemStack(Items.QUARTZ));
					entityToSpawn.setPickupDelay((int) 10);
					world.addEntity(entityToSpawn);
				}
			} else if (random == 9) {
				if (world instanceof World && !world.isRemote()) {
					ItemEntity entityToSpawn = new ItemEntity((World) world, (x + MathHelper.nextInt(new Random(), -4, 4)), (y + 1),
							(z + MathHelper.nextInt(new Random(), -4, 4)), new ItemStack(Items.QUARTZ));
					entityToSpawn.setPickupDelay((int) 10);
					world.addEntity(entityToSpawn);
				}
			}
			new Object() {
				private int ticks = 0;
				private float waitTicks;
				private IWorld world;

				public void start(IWorld world, int waitTicks) {
					this.waitTicks = waitTicks;
					MinecraftForge.EVENT_BUS.register(this);
					this.world = world;
				}

				@SubscribeEvent
				public void tick(TickEvent.ServerTickEvent event) {
					if (event.phase == TickEvent.Phase.END) {
						this.ticks += 1;
						if (this.ticks >= this.waitTicks)
							run();
					}
				}

				private void run() {
					if (world instanceof World && !world.isRemote()) {
						((World) world).playSound(null, new BlockPos(x, y, z),
								(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("tboi_suzu:justice")),
								SoundCategory.VOICE, (float) 1, (float) 1);
					} else {
						((World) world).playSound(x, y, z,
								(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("tboi_suzu:justice")),
								SoundCategory.VOICE, (float) 1, (float) 1, false);
					}
					MinecraftForge.EVENT_BUS.unregister(this);
				}
			}.start(world, (int) 10);
		}
	}
}
