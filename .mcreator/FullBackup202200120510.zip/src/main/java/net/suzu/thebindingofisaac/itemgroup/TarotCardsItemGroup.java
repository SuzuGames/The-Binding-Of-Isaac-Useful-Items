
package net.suzu.thebindingofisaac.itemgroup;

import net.suzu.thebindingofisaac.item.TarotCardItem;
import net.suzu.thebindingofisaac.TboiSuzuModElements;

import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemGroup;

@TboiSuzuModElements.ModElement.Tag
public class TarotCardsItemGroup extends TboiSuzuModElements.ModElement {
	public TarotCardsItemGroup(TboiSuzuModElements instance) {
		super(instance, 76);
	}

	@Override
	public void initElements() {
		tab = new ItemGroup("tabtarot_cards") {
			@OnlyIn(Dist.CLIENT)
			@Override
			public ItemStack createIcon() {
				return new ItemStack(TarotCardItem.block);
			}

			@OnlyIn(Dist.CLIENT)
			public boolean hasSearchBar() {
				return false;
			}
		};
	}

	public static ItemGroup tab;
}
