
package net.suzu.thebindingofisaac.potion;

import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;

public class HolyMantleMobEffect extends MobEffect {
	public HolyMantleMobEffect() {
		super(MobEffectCategory.NEUTRAL, -13382401);
	}

	@Override
	public String getDescriptionId() {
		return "effect.tboi_suzu.holy_mantle";
	}

	@Override
	public boolean isDurationEffectTick(int duration, int amplifier) {
		return true;
	}
}
