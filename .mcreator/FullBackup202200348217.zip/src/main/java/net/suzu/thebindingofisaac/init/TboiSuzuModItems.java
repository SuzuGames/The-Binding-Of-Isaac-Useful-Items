
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.suzu.thebindingofisaac.init;

import net.suzu.thebindingofisaac.item.WheelOfFortuneItem;
import net.suzu.thebindingofisaac.item.TheWorldItem;
import net.suzu.thebindingofisaac.item.TheTowerItem;
import net.suzu.thebindingofisaac.item.TheSunItem;
import net.suzu.thebindingofisaac.item.TheStarsItem;
import net.suzu.thebindingofisaac.item.TheMoonItem;
import net.suzu.thebindingofisaac.item.TheMagicianItem;
import net.suzu.thebindingofisaac.item.TheLoversItem;
import net.suzu.thebindingofisaac.item.TheHighPriestessItem;
import net.suzu.thebindingofisaac.item.TheHierophantItem;
import net.suzu.thebindingofisaac.item.TheHermitItem;
import net.suzu.thebindingofisaac.item.TheHangedManItem;
import net.suzu.thebindingofisaac.item.TheFoolItem;
import net.suzu.thebindingofisaac.item.TheEmpressItem;
import net.suzu.thebindingofisaac.item.TheEmperorItem;
import net.suzu.thebindingofisaac.item.TheDevilItem;
import net.suzu.thebindingofisaac.item.TheChariotItem;
import net.suzu.thebindingofisaac.item.TheBookOfBelialItem;
import net.suzu.thebindingofisaac.item.TemperanceItem;
import net.suzu.thebindingofisaac.item.TearProjectileItem;
import net.suzu.thebindingofisaac.item.TarotCardItem;
import net.suzu.thebindingofisaac.item.StrengthItem;
import net.suzu.thebindingofisaac.item.SoulHeartItem;
import net.suzu.thebindingofisaac.item.SamsonTearItem;
import net.suzu.thebindingofisaac.item.RedHeartItem;
import net.suzu.thebindingofisaac.item.RazorBladeItem;
import net.suzu.thebindingofisaac.item.RKeyItem;
import net.suzu.thebindingofisaac.item.Pill9Item;
import net.suzu.thebindingofisaac.item.Pill8Item;
import net.suzu.thebindingofisaac.item.Pill7Item;
import net.suzu.thebindingofisaac.item.Pill6Item;
import net.suzu.thebindingofisaac.item.Pill5Item;
import net.suzu.thebindingofisaac.item.Pill4Item;
import net.suzu.thebindingofisaac.item.Pill3Item;
import net.suzu.thebindingofisaac.item.Pill2Item;
import net.suzu.thebindingofisaac.item.Pill1Item;
import net.suzu.thebindingofisaac.item.Pill13Item;
import net.suzu.thebindingofisaac.item.Pill12Item;
import net.suzu.thebindingofisaac.item.Pill11Item;
import net.suzu.thebindingofisaac.item.Pill10Item;
import net.suzu.thebindingofisaac.item.PennyItem;
import net.suzu.thebindingofisaac.item.NothingItem;
import net.suzu.thebindingofisaac.item.NickelItem;
import net.suzu.thebindingofisaac.item.MusicDiscGenesisItem;
import net.suzu.thebindingofisaac.item.MomsBottleOfPillsItem;
import net.suzu.thebindingofisaac.item.MagdaleneTearItem;
import net.suzu.thebindingofisaac.item.KeyItem;
import net.suzu.thebindingofisaac.item.JusticeItem;
import net.suzu.thebindingofisaac.item.JudgementItem;
import net.suzu.thebindingofisaac.item.JudasTearItem;
import net.suzu.thebindingofisaac.item.IsaacTearItem;
import net.suzu.thebindingofisaac.item.HowToJumpItem;
import net.suzu.thebindingofisaac.item.HolyCardItem;
import net.suzu.thebindingofisaac.item.GuppysPawItem;
import net.suzu.thebindingofisaac.item.GoldenKeyItem;
import net.suzu.thebindingofisaac.item.GoldenBombItem;
import net.suzu.thebindingofisaac.item.ForgottenLullabyItem;
import net.suzu.thebindingofisaac.item.EvaWhoreOfBabylonTearItem;
import net.suzu.thebindingofisaac.item.EvaTearItem;
import net.suzu.thebindingofisaac.item.EternalHeartItem;
import net.suzu.thebindingofisaac.item.DimeItem;
import net.suzu.thebindingofisaac.item.DeathItem;
import net.suzu.thebindingofisaac.item.DadsKeyItem;
import net.suzu.thebindingofisaac.item.CrackTheSkyItem;
import net.suzu.thebindingofisaac.item.ChargedWheelOfFortuneItem;
import net.suzu.thebindingofisaac.item.ChargedTheWorldItem;
import net.suzu.thebindingofisaac.item.ChargedTheTowerItem;
import net.suzu.thebindingofisaac.item.ChargedTheSunItem;
import net.suzu.thebindingofisaac.item.ChargedTheStarsItem;
import net.suzu.thebindingofisaac.item.ChargedTheMoonItem;
import net.suzu.thebindingofisaac.item.ChargedTheMagicianItem;
import net.suzu.thebindingofisaac.item.ChargedTheLoversItem;
import net.suzu.thebindingofisaac.item.ChargedTheHighPriestessItem;
import net.suzu.thebindingofisaac.item.ChargedTheHierophantItem;
import net.suzu.thebindingofisaac.item.ChargedTheHermitItem;
import net.suzu.thebindingofisaac.item.ChargedTheHangedManItem;
import net.suzu.thebindingofisaac.item.ChargedTheFoolItem;
import net.suzu.thebindingofisaac.item.ChargedTheEmperorItem;
import net.suzu.thebindingofisaac.item.ChargedTheDevilItem;
import net.suzu.thebindingofisaac.item.ChargedTheChariotItem;
import net.suzu.thebindingofisaac.item.ChargedTemperanceItem;
import net.suzu.thebindingofisaac.item.ChargedStrenghItem;
import net.suzu.thebindingofisaac.item.ChargedJusticeItem;
import net.suzu.thebindingofisaac.item.ChargedJudgementItem;
import net.suzu.thebindingofisaac.item.ChargedDeathItem;
import net.suzu.thebindingofisaac.item.CainTearItem;
import net.suzu.thebindingofisaac.item.BookOfShadowsItem;
import net.suzu.thebindingofisaac.item.BombItem;
import net.suzu.thebindingofisaac.item.BlueBabyTearItem;
import net.suzu.thebindingofisaac.item.BlendedHeartItem;
import net.suzu.thebindingofisaac.item.BlackHeartItem;
import net.suzu.thebindingofisaac.item.BigBombItem;
import net.suzu.thebindingofisaac.item.AzazelTearItem;
import net.suzu.thebindingofisaac.item.AnarchistCookbookItem;
import net.suzu.thebindingofisaac.TboiSuzuMod;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BlockItem;

public class TboiSuzuModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, TboiSuzuMod.MODID);
	public static final RegistryObject<Item> THE_FOOL = REGISTRY.register("the_fool", () -> new TheFoolItem());
	public static final RegistryObject<Item> THE_MAGICIAN = REGISTRY.register("the_magician", () -> new TheMagicianItem());
	public static final RegistryObject<Item> THE_HIGH_PRIESTESS = REGISTRY.register("the_high_priestess", () -> new TheHighPriestessItem());
	public static final RegistryObject<Item> THE_EMPRESS = REGISTRY.register("the_empress", () -> new TheEmpressItem());
	public static final RegistryObject<Item> THE_EMPEROR = REGISTRY.register("the_emperor", () -> new TheEmperorItem());
	public static final RegistryObject<Item> THE_HIEROPHANT = REGISTRY.register("the_hierophant", () -> new TheHierophantItem());
	public static final RegistryObject<Item> THE_LOVERS = REGISTRY.register("the_lovers", () -> new TheLoversItem());
	public static final RegistryObject<Item> THE_CHARIOT = REGISTRY.register("the_chariot", () -> new TheChariotItem());
	public static final RegistryObject<Item> JUSTICE = REGISTRY.register("justice", () -> new JusticeItem());
	public static final RegistryObject<Item> THE_HERMIT = REGISTRY.register("the_hermit", () -> new TheHermitItem());
	public static final RegistryObject<Item> WHEEL_OF_FORTUNE = REGISTRY.register("wheel_of_fortune", () -> new WheelOfFortuneItem());
	public static final RegistryObject<Item> STRENGTH = REGISTRY.register("strength", () -> new StrengthItem());
	public static final RegistryObject<Item> THE_HANGED_MAN = REGISTRY.register("the_hanged_man", () -> new TheHangedManItem());
	public static final RegistryObject<Item> DEATH = REGISTRY.register("death", () -> new DeathItem());
	public static final RegistryObject<Item> TEMPERANCE = REGISTRY.register("temperance", () -> new TemperanceItem());
	public static final RegistryObject<Item> THE_DEVIL = REGISTRY.register("the_devil", () -> new TheDevilItem());
	public static final RegistryObject<Item> THE_TOWER = REGISTRY.register("the_tower", () -> new TheTowerItem());
	public static final RegistryObject<Item> THE_STARS = REGISTRY.register("the_stars", () -> new TheStarsItem());
	public static final RegistryObject<Item> THE_MOON = REGISTRY.register("the_moon", () -> new TheMoonItem());
	public static final RegistryObject<Item> THE_SUN = REGISTRY.register("the_sun", () -> new TheSunItem());
	public static final RegistryObject<Item> JUDGEMENT = REGISTRY.register("judgement", () -> new JudgementItem());
	public static final RegistryObject<Item> THE_WORLD = REGISTRY.register("the_world", () -> new TheWorldItem());
	public static final RegistryObject<Item> CHARGED_THE_FOOL = REGISTRY.register("charged_the_fool", () -> new ChargedTheFoolItem());
	public static final RegistryObject<Item> CHARGED_THE_MAGICIAN = REGISTRY.register("charged_the_magician", () -> new ChargedTheMagicianItem());
	public static final RegistryObject<Item> CHARGED_THE_HIGH_PRIESTESS = REGISTRY.register("charged_the_high_priestess",
			() -> new ChargedTheHighPriestessItem());
	public static final RegistryObject<Item> CHARGED_THE_EMPEROR = REGISTRY.register("charged_the_emperor", () -> new ChargedTheEmperorItem());
	public static final RegistryObject<Item> CHARGED_THE_HIEROPHANT = REGISTRY.register("charged_the_hierophant",
			() -> new ChargedTheHierophantItem());
	public static final RegistryObject<Item> CHARGED_THE_LOVERS = REGISTRY.register("charged_the_lovers", () -> new ChargedTheLoversItem());
	public static final RegistryObject<Item> CHARGED_THE_CHARIOT = REGISTRY.register("charged_the_chariot", () -> new ChargedTheChariotItem());
	public static final RegistryObject<Item> CHARGED_JUSTICE = REGISTRY.register("charged_justice", () -> new ChargedJusticeItem());
	public static final RegistryObject<Item> CHARGED_THE_HERMIT = REGISTRY.register("charged_the_hermit", () -> new ChargedTheHermitItem());
	public static final RegistryObject<Item> CHARGED_WHEEL_OF_FORTUNE = REGISTRY.register("charged_wheel_of_fortune",
			() -> new ChargedWheelOfFortuneItem());
	public static final RegistryObject<Item> CHARGED_STRENGH = REGISTRY.register("charged_strengh", () -> new ChargedStrenghItem());
	public static final RegistryObject<Item> CHARGED_THE_HANGED_MAN = REGISTRY.register("charged_the_hanged_man",
			() -> new ChargedTheHangedManItem());
	public static final RegistryObject<Item> CHARGED_DEATH = REGISTRY.register("charged_death", () -> new ChargedDeathItem());
	public static final RegistryObject<Item> CHARGED_TEMPERANCE = REGISTRY.register("charged_temperance", () -> new ChargedTemperanceItem());
	public static final RegistryObject<Item> CHARGED_THE_DEVIL = REGISTRY.register("charged_the_devil", () -> new ChargedTheDevilItem());
	public static final RegistryObject<Item> CHARGED_THE_TOWER = REGISTRY.register("charged_the_tower", () -> new ChargedTheTowerItem());
	public static final RegistryObject<Item> CHARGED_THE_STARS = REGISTRY.register("charged_the_stars", () -> new ChargedTheStarsItem());
	public static final RegistryObject<Item> CHARGED_THE_MOON = REGISTRY.register("charged_the_moon", () -> new ChargedTheMoonItem());
	public static final RegistryObject<Item> CHARGED_THE_SUN = REGISTRY.register("charged_the_sun", () -> new ChargedTheSunItem());
	public static final RegistryObject<Item> CHARGED_JUDGEMENT = REGISTRY.register("charged_judgement", () -> new ChargedJudgementItem());
	public static final RegistryObject<Item> CHARGED_THE_WORLD = REGISTRY.register("charged_the_world", () -> new ChargedTheWorldItem());
	public static final RegistryObject<Item> MARK_STONE = block(TboiSuzuModBlocks.MARK_STONE, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> RED_HEART = REGISTRY.register("red_heart", () -> new RedHeartItem());
	public static final RegistryObject<Item> SOUL_HEART = REGISTRY.register("soul_heart", () -> new SoulHeartItem());
	public static final RegistryObject<Item> BLENDED_HEART = REGISTRY.register("blended_heart", () -> new BlendedHeartItem());
	public static final RegistryObject<Item> ETERNAL_HEART = REGISTRY.register("eternal_heart", () -> new EternalHeartItem());
	public static final RegistryObject<Item> PILL_1 = REGISTRY.register("pill_1", () -> new Pill1Item());
	public static final RegistryObject<Item> PILL_2 = REGISTRY.register("pill_2", () -> new Pill2Item());
	public static final RegistryObject<Item> PILL_3 = REGISTRY.register("pill_3", () -> new Pill3Item());
	public static final RegistryObject<Item> PILL_4 = REGISTRY.register("pill_4", () -> new Pill4Item());
	public static final RegistryObject<Item> PILL_5 = REGISTRY.register("pill_5", () -> new Pill5Item());
	public static final RegistryObject<Item> PILL_6 = REGISTRY.register("pill_6", () -> new Pill6Item());
	public static final RegistryObject<Item> PILL_7 = REGISTRY.register("pill_7", () -> new Pill7Item());
	public static final RegistryObject<Item> PILL_8 = REGISTRY.register("pill_8", () -> new Pill8Item());
	public static final RegistryObject<Item> PILL_9 = REGISTRY.register("pill_9", () -> new Pill9Item());
	public static final RegistryObject<Item> PILL_10 = REGISTRY.register("pill_10", () -> new Pill10Item());
	public static final RegistryObject<Item> PILL_11 = REGISTRY.register("pill_11", () -> new Pill11Item());
	public static final RegistryObject<Item> PILL_12 = REGISTRY.register("pill_12", () -> new Pill12Item());
	public static final RegistryObject<Item> PILL_13 = REGISTRY.register("pill_13", () -> new Pill13Item());
	public static final RegistryObject<Item> PENNY = REGISTRY.register("penny", () -> new PennyItem());
	public static final RegistryObject<Item> NICKEL = REGISTRY.register("nickel", () -> new NickelItem());
	public static final RegistryObject<Item> DIME = REGISTRY.register("dime", () -> new DimeItem());
	public static final RegistryObject<Item> BOMB = REGISTRY.register("bomb", () -> new BombItem());
	public static final RegistryObject<Item> GOLDEN_BOMB = REGISTRY.register("golden_bomb", () -> new GoldenBombItem());
	public static final RegistryObject<Item> BIG_BOMB = REGISTRY.register("big_bomb", () -> new BigBombItem());
	public static final RegistryObject<Item> NORMAL_CHEST = block(TboiSuzuModBlocks.NORMAL_CHEST, TboiSuzuModTabs.TAB_CHESTS);
	public static final RegistryObject<Item> RED_CHEST = block(TboiSuzuModBlocks.RED_CHEST, TboiSuzuModTabs.TAB_CHESTS);
	public static final RegistryObject<Item> GOLDEN_CHEST = block(TboiSuzuModBlocks.GOLDEN_CHEST, TboiSuzuModTabs.TAB_CHESTS);
	public static final RegistryObject<Item> ANGEL_CHEST = block(TboiSuzuModBlocks.ANGEL_CHEST, TboiSuzuModTabs.TAB_CHESTS);
	public static final RegistryObject<Item> KEY = REGISTRY.register("key", () -> new KeyItem());
	public static final RegistryObject<Item> GOLDEN_KEY = REGISTRY.register("golden_key", () -> new GoldenKeyItem());
	public static final RegistryObject<Item> TAROT_CARD = REGISTRY.register("tarot_card", () -> new TarotCardItem());
	public static final RegistryObject<Item> RAZOR_BLADE = REGISTRY.register("razor_blade", () -> new RazorBladeItem());
	public static final RegistryObject<Item> DADS_KEY = REGISTRY.register("dads_key", () -> new DadsKeyItem());
	public static final RegistryObject<Item> GUPPYS_PAW = REGISTRY.register("guppys_paw", () -> new GuppysPawItem());
	public static final RegistryObject<Item> HOW_TO_JUMP = REGISTRY.register("how_to_jump", () -> new HowToJumpItem());
	public static final RegistryObject<Item> SLOT_MACHINE = block(TboiSuzuModBlocks.SLOT_MACHINE, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> BLOOD_MACHINE = block(TboiSuzuModBlocks.BLOOD_MACHINE, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> ISAAC = REGISTRY.register("isaac_spawn_egg",
			() -> new ForgeSpawnEggItem(TboiSuzuModEntities.ISAAC, -3302758, -5120030, new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> GAPER = REGISTRY.register("gaper_spawn_egg",
			() -> new ForgeSpawnEggItem(TboiSuzuModEntities.GAPER, -1, -1, new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> MAGDALENE = REGISTRY.register("magdalene_spawn_egg",
			() -> new ForgeSpawnEggItem(TboiSuzuModEntities.MAGDALENE, -3302758, -256, new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> FLY = REGISTRY.register("fly_spawn_egg",
			() -> new ForgeSpawnEggItem(TboiSuzuModEntities.FLY, -10066330, -52429, new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> CAIN = REGISTRY.register("cain_spawn_egg",
			() -> new ForgeSpawnEggItem(TboiSuzuModEntities.CAIN, -3302758, -16777216, new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> JUDAS = REGISTRY.register("judas_spawn_egg",
			() -> new ForgeSpawnEggItem(TboiSuzuModEntities.JUDAS, -1, -1, new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> BLUE_BABY = REGISTRY.register("blue_baby_spawn_egg",
			() -> new ForgeSpawnEggItem(TboiSuzuModEntities.BLUE_BABY, -1, -1, new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> EVA = REGISTRY.register("eva_spawn_egg",
			() -> new ForgeSpawnEggItem(TboiSuzuModEntities.EVA, -1, -1, new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> SAMSON = REGISTRY.register("samson_spawn_egg",
			() -> new ForgeSpawnEggItem(TboiSuzuModEntities.SAMSON, -1, -1, new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> ISAAC_TEAR = REGISTRY.register("isaac_tear", () -> new IsaacTearItem());
	public static final RegistryObject<Item> MAGDALENE_TEAR = REGISTRY.register("magdalene_tear", () -> new MagdaleneTearItem());
	public static final RegistryObject<Item> CAIN_TEAR = REGISTRY.register("cain_tear", () -> new CainTearItem());
	public static final RegistryObject<Item> JUDAS_TEAR = REGISTRY.register("judas_tear", () -> new JudasTearItem());
	public static final RegistryObject<Item> BLUE_BABY_TEAR = REGISTRY.register("blue_baby_tear", () -> new BlueBabyTearItem());
	public static final RegistryObject<Item> EVA_TEAR = REGISTRY.register("eva_tear", () -> new EvaTearItem());
	public static final RegistryObject<Item> SAMSON_TEAR = REGISTRY.register("samson_tear", () -> new SamsonTearItem());
	public static final RegistryObject<Item> EVA_WHORE_OF_BABYLON_TEAR = REGISTRY.register("eva_whore_of_babylon_tear",
			() -> new EvaWhoreOfBabylonTearItem());
	public static final RegistryObject<Item> THE_BOOK_OF_BELIAL = REGISTRY.register("the_book_of_belial", () -> new TheBookOfBelialItem());
	public static final RegistryObject<Item> AZAZEL = REGISTRY.register("azazel_spawn_egg",
			() -> new ForgeSpawnEggItem(TboiSuzuModEntities.AZAZEL, -14013910, -65536, new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> AZAZEL_TEAR = REGISTRY.register("azazel_tear", () -> new AzazelTearItem());
	public static final RegistryObject<Item> NOTHING = REGISTRY.register("nothing", () -> new NothingItem());
	public static final RegistryObject<Item> TEAR_PROJECTILE = REGISTRY.register("tear_projectile", () -> new TearProjectileItem());
	public static final RegistryObject<Item> DEVILS_COBBLESTONE = block(TboiSuzuModBlocks.DEVILS_COBBLESTONE, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> BLACK_HEART = REGISTRY.register("black_heart", () -> new BlackHeartItem());
	public static final RegistryObject<Item> MUSIC_DISC_GENESIS = REGISTRY.register("music_disc_genesis", () -> new MusicDiscGenesisItem());
	public static final RegistryObject<Item> ANARCHIST_COOKBOOK = REGISTRY.register("anarchist_cookbook", () -> new AnarchistCookbookItem());
	public static final RegistryObject<Item> BOOK_OF_SHADOWS = REGISTRY.register("book_of_shadows", () -> new BookOfShadowsItem());
	public static final RegistryObject<Item> CRACK_THE_SKY = REGISTRY.register("crack_the_sky", () -> new CrackTheSkyItem());
	public static final RegistryObject<Item> FORGOTTEN_LULLABY = REGISTRY.register("forgotten_lullaby", () -> new ForgottenLullabyItem());
	public static final RegistryObject<Item> MOMS_BOTTLE_OF_PILLS = REGISTRY.register("moms_bottle_of_pills", () -> new MomsBottleOfPillsItem());
	public static final RegistryObject<Item> R_KEY = REGISTRY.register("r_key", () -> new RKeyItem());
	public static final RegistryObject<Item> BEGGAR = REGISTRY.register("beggar_spawn_egg",
			() -> new ForgeSpawnEggItem(TboiSuzuModEntities.BEGGAR, -1849659, -8033949, new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> HOLY_CARD = REGISTRY.register("holy_card", () -> new HolyCardItem());

	private static RegistryObject<Item> block(RegistryObject<Block> block, CreativeModeTab tab) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties().tab(tab)));
	}
}
