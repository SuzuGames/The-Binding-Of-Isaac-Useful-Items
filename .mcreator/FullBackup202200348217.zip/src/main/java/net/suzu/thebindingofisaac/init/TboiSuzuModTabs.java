
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.suzu.thebindingofisaac.init;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;

public class TboiSuzuModTabs {
	public static CreativeModeTab TAB_TAROT_CARDS;
	public static CreativeModeTab TAB_HEARTS;
	public static CreativeModeTab TAB_PILLS;
	public static CreativeModeTab TAB_PENNIES;
	public static CreativeModeTab TAB_BOMBS;
	public static CreativeModeTab TAB_CHESTS;
	public static CreativeModeTab TAB_KEYS;
	public static CreativeModeTab TAB_ITEMS;
	public static CreativeModeTab TAB_SOUNDTRACK;

	public static void load() {
		TAB_TAROT_CARDS = new CreativeModeTab("tabtarot_cards") {
			@Override
			public ItemStack makeIcon() {
				return new ItemStack(TboiSuzuModItems.TAROT_CARD.get());
			}

			@Override
			public boolean hasSearchBar() {
				return false;
			}
		};
		TAB_HEARTS = new CreativeModeTab("tabhearts") {
			@Override
			public ItemStack makeIcon() {
				return new ItemStack(TboiSuzuModItems.RED_HEART.get());
			}

			@Override
			public boolean hasSearchBar() {
				return false;
			}
		};
		TAB_PILLS = new CreativeModeTab("tabpills") {
			@Override
			public ItemStack makeIcon() {
				return new ItemStack(TboiSuzuModItems.PILL_1.get());
			}

			@Override
			public boolean hasSearchBar() {
				return false;
			}
		};
		TAB_PENNIES = new CreativeModeTab("tabpennies") {
			@Override
			public ItemStack makeIcon() {
				return new ItemStack(TboiSuzuModItems.PENNY.get());
			}

			@Override
			public boolean hasSearchBar() {
				return false;
			}
		};
		TAB_BOMBS = new CreativeModeTab("tabbombs") {
			@Override
			public ItemStack makeIcon() {
				return new ItemStack(TboiSuzuModItems.BOMB.get());
			}

			@Override
			public boolean hasSearchBar() {
				return false;
			}
		};
		TAB_CHESTS = new CreativeModeTab("tabchests") {
			@Override
			public ItemStack makeIcon() {
				return new ItemStack(TboiSuzuModBlocks.GOLDEN_CHEST.get());
			}

			@Override
			public boolean hasSearchBar() {
				return false;
			}
		};
		TAB_KEYS = new CreativeModeTab("tabkeys") {
			@Override
			public ItemStack makeIcon() {
				return new ItemStack(TboiSuzuModItems.KEY.get());
			}

			@Override
			public boolean hasSearchBar() {
				return false;
			}
		};
		TAB_ITEMS = new CreativeModeTab("tabitems") {
			@Override
			public ItemStack makeIcon() {
				return new ItemStack(TboiSuzuModItems.GUPPYS_PAW.get());
			}

			@Override
			public boolean hasSearchBar() {
				return true;
			}
		}.setBackgroundSuffix("item_search.png");
		TAB_SOUNDTRACK = new CreativeModeTab("tabsoundtrack") {
			@Override
			public ItemStack makeIcon() {
				return new ItemStack(TboiSuzuModItems.FORGOTTEN_LULLABY.get());
			}

			@Override
			public boolean hasSearchBar() {
				return true;
			}
		}.setBackgroundSuffix("item_search.png");
	}
}
