
package net.suzu.thebindingofisaac.item;

import net.suzu.thebindingofisaac.init.TboiSuzuModTabs;

import net.minecraftforge.registries.ForgeRegistries;

import net.minecraft.world.item.RecordItem;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;
import net.minecraft.resources.ResourceLocation;

public class MusicDiscGenesisItem extends RecordItem {
	public MusicDiscGenesisItem() {
		super(0, () -> ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("tboi_suzu:record.genesis")),
				new Item.Properties().tab(TboiSuzuModTabs.TAB_SOUNDTRACK).stacksTo(1).rarity(Rarity.RARE), 100);
	}
}
