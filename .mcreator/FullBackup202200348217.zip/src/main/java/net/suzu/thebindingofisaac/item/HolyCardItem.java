
package net.suzu.thebindingofisaac.item;

import net.suzu.thebindingofisaac.init.TboiSuzuModTabs;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class HolyCardItem extends Item {
	public HolyCardItem() {
		super(new Item.Properties().tab(TboiSuzuModTabs.TAB_TAROT_CARDS).stacksTo(64).rarity(Rarity.COMMON));
	}
}
